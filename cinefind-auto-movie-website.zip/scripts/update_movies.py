#!/usr/bin/env python3
"""Best-effort public listing metadata updater. No video downloads or access-control bypass."""
import json, re, os, sys, urllib.request, urllib.error
from html.parser import HTMLParser
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse

SOURCE_URL = os.environ.get("SOURCE_URL", "https://southfreak.club/")
OUTPUT = os.path.join(os.path.dirname(__file__), "..", "data", "movies.json")
USER_AGENT = "CineFindPublicListingIndexer/1.0 (metadata and outbound links only)"
TIMEOUT = 20

class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__(); self.links=[]; self.current=None
    def handle_starttag(self, tag, attrs):
        attrs=dict(attrs)
        if tag.lower()=="a" and attrs.get("href"):
            self.current={"href":attrs["href"],"text":""}
    def handle_data(self, data):
        if self.current is not None: self.current["text"] += " "+data
    def handle_endtag(self, tag):
        if tag.lower()=="a" and self.current is not None:
            self.links.append(self.current); self.current=None

def fetch(url):
    req=urllib.request.Request(url, headers={"User-Agent":USER_AGENT,"Accept":"text/html,application/rss+xml,application/atom+xml;q=0.9,*/*;q=0.5"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        if r.status != 200: raise RuntimeError("HTTP status "+str(r.status))
        return r.read(4_000_000), r.headers.get("Content-Type","")

def plain(s):
    return re.sub(r"\s+"," ",re.sub(r"<[^>]+>"," ",s)).strip()

def guess_category(title, url):
    s=(title+" "+url).lower()
    rules=[("Web Series",["web series","season","episode","s01","s02","series"]),("Bengali",["bengali","bangla","natok","telefilm"]),("Tamil",["tamil"]),("Telugu",["telugu"]),("Malayalam",["malayalam"]),("Kannada",["kannada"]),("Bollywood",["bollywood","hindi"]),("Hollywood",["hollywood","english"]),("Korean",["korean","k-drama"]),("Japanese",["japanese"]),("Chinese",["chinese"]),("Drama",["drama","natok"])]
    for cat,words in rules:
        if any(w in s for w in words): return cat
    return "Other"

def load_old():
    try:
        with open(OUTPUT,encoding="utf-8") as f: data=json.load(f)
        return data.get("movies",[])
    except Exception: return []

def parse_feed(text, base_url):
    # RSS/Atom XML, using stdlib parsing. Extract titles and link URLs only.
    import xml.etree.ElementTree as ET
    root=ET.fromstring(text)
    out=[]
    for item in root.iter():
        tag=item.tag.split("}")[-1].lower()
        if tag not in ("item","entry"): continue
        title=""; link=""; pub=""
        for child in item.iter():
            ctag=child.tag.split("}")[-1].lower()
            if ctag=="title" and child.text: title=plain(child.text)
            elif ctag=="link":
                href=child.attrib.get("href") or child.text
                if href and (not link or child.attrib.get("rel","alternate")=="alternate"): link=urljoin(base_url,href.strip())
            elif ctag in ("pubdate","published","updated") and child.text: pub=child.text.strip()
        if title and link and link.startswith(("http://","https://")):
            out.append({"title":title[:180],"category":guess_category(title,link),"year":"","source_url":link,"description":"Open the original source page.","published_at":pub[:40]})
    return out

def main():
    old=load_old()
    candidates=[]
    feed_urls=[urljoin(SOURCE_URL,"feed/"),urljoin(SOURCE_URL,"feed"),urljoin(SOURCE_URL,"?feed=rss2")]
    # Prefer RSS/Atom when available.
    for u in feed_urls:
        try:
            body,ctype=fetch(u)
            if b"<rss" in body[:2000].lower() or b"<feed" in body[:2000].lower() or "xml" in ctype.lower():
                candidates=parse_feed(body.decode("utf-8","replace"),u)
                if candidates: break
        except Exception: pass
    if not candidates:
        try:
            body,ctype=fetch(SOURCE_URL)
            parser=LinkParser(); parser.feed(body.decode("utf-8","replace"))
            base=urlparse(SOURCE_URL)
            seen=set()
            for a in parser.links:
                title=plain(a["text"]); url=urljoin(SOURCE_URL,a["href"])
                p=urlparse(url)
                if not title or len(title)<3 or len(title)>180: continue
                if p.scheme not in ("http","https"): continue
                if p.netloc.lower()!=base.netloc.lower(): continue
                if any(x in url.lower() for x in ("wp-content","wp-json","/tag/","/category/","/author/","/page/","javascript:","#")): continue
                if url.rstrip("/") in (SOURCE_URL.rstrip("/"),): continue
                # Conservative heuristic: only likely content permalinks with a descriptive title.
                if len(title.split()) < 2: continue
                key=url.split("#")[0]
                if key in seen: continue
                seen.add(key)
                candidates.append({"title":title[:180],"category":guess_category(title,url),"year":"","source_url":url,"description":"Open the original source page.","published_at":""})
        except Exception as e:
            print("WARNING: could not fetch public source page:",e,file=sys.stderr)
    # Keep only unique URLs, favor fresh results, cap listing count.
    merged=[]; seen=set()
    for item in candidates+old:
        url=item.get("source_url","")
        if not url.startswith(("http://","https://")) or url in seen: continue
        seen.add(url); merged.append(item)
    if not candidates:
        print("WARNING: no compatible public feed/listings found; retaining existing entries.")
        merged=old
    merged=merged[:250]
    os.makedirs(os.path.dirname(OUTPUT),exist_ok=True)
    with open(OUTPUT,"w",encoding="utf-8") as f:
        json.dump({"updated_at":datetime.now(timezone.utc).isoformat(),"source_url":SOURCE_URL,"movies":merged},f,ensure_ascii=False,indent=2)
    print(f"Saved {len(merged)} listings; new candidates: {len(candidates)}")

if __name__=="__main__": main()
